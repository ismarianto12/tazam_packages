<script src="{{ pkg_asset('dash', 'dependencies/datatables/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ pkg_asset('dash', 'dependencies/datatables/js/dataTables.bootstrap4.min.js') }}"></script>
