<div class="col-md-6 col-xl-3">
    <div class="card mb-3 widget-content bg-midnight-bloom">
        <div class="widget-content-outer text-white">
            <div class="widget-content-wrapper">
                <div class="widget-content-left">
                    <div class="widget-heading">{{$title}}</div>
                    <div class="widget-subheading">{{$subtitle}}</div>
                </div>
                <div class="widget-content-right">
                    <div class="widget-numbers text-{{$color}}">{{$value}}</div>
                </div>
            </div>
        </div>
    </div>
</div>