<script src="{{ pkg_asset('dash', 'dependencies/summernote/summernote-lite.min.js') }}"></script>
