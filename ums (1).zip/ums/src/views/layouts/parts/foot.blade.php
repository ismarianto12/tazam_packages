<!-- jQuery -->
<script src="{{ pkg_asset('dash', 'dependencies/jquery/jquery.min.js') }}"></script>

<!-- Bootstrap Core JavaScript -->
<script src="{{ pkg_asset('dash', 'dependencies/popper/popper.min.js') }}"></script>
<script src="{{ pkg_asset('dash', 'dependencies/bootstrap/js/bootstrap.min.js') }}"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="{{ pkg_asset('dash', 'dependencies/metisMenu/metisMenu.min.js') }}"></script>

<script src="{{ pkg_asset('dash', 'js/sb-admin-2.js') }}"></script>