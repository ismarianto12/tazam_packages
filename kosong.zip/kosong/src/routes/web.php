<?php

Route::group(['prefix' => '/kosong', 'as' => 'kosong.', 'middleware' => ['web']], function () {
	Route::get('/install', 'Bryanjack\Kosong\App\Commands\KosongInstall@createMenu');
});

Route::group(['namespace' => 'Bryanjack\Kosong\Controllers', 'prefix' => '/kosong', 'as' => 'kosong.', 'middleware' => ['web']], function () {
	Route::get('/', 'KosongController@index');
});
