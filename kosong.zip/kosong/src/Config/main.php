<?php

return [
    'theme' => [
        'main' => 'kosong'
    ]
];
