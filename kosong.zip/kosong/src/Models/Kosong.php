<?php

namespace Bryanjack\Kosong\Models;

use Illuminate\Database\Eloquent\Model;

class Kosong extends Model
{
    protected $fillable = [
        'name', 'duration', 'status'
    ];
}
